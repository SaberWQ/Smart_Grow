"""
SmartGrow - Django Project Package
"""
